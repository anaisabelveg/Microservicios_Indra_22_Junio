-- los pw estan encriptados y son "12345"
INSERT INTO usuarios(username, password, enabled, nombre, apellido, email) values ('juan', '12345', 1, 'Juan', 'Lopez', 'juan@gmail.com');
INSERT INTO usuarios(username, password, enabled, nombre, apellido, email) values ('admin', '12345', 1, 'Maria', 'Rodriguez', 'maria@gmail.com');

INSERT INTO roles(nombre) values ('ROLE_USER');
INSERT INTO roles(nombre) values ('ROLE_ADMIN');

INSERT INTO usuarios_roles(usuario_id, role_id) values (1,1);
INSERT INTO usuarios_roles(usuario_id, role_id) values (2,1);
INSERT INTO usuarios_roles(usuario_id, role_id) values (2,2);