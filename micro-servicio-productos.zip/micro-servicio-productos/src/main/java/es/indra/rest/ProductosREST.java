package es.indra.rest;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProductosBS;
import es.indra.entities.Producto;

@RestController   // Es un bean de Spring
//@RequestMapping("/api")
public class ProductosREST {
	
	// Para inyectar este bean, 2 opciones:
	//	1ª poner la anotacion @Autowired
	//  2ª crear el constructor que recibe este bean como parametro
	private IProductosBS bs;
	
	public ProductosREST(IProductosBS bs) {
		super();
		this.bs = bs;
	}

	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return bs.consultarTodos();
	}
	
	// http://localhost:8001/buscar/4
	@GetMapping("/buscar/{codigo}")
	public Producto buscar(@PathVariable(name = "codigo") Long id) {
		return bs.buscarProducto(id);
	}

}
