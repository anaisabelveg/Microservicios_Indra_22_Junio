package es.indra.rest;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProductosBS;
import es.indra.entities.Producto;

@RestController   // Es un bean de Spring
//@RequestMapping("/api")
@Validated   // Necesario para activar las reglas de validacion
public class ProductosREST {
	
	// Para inyectar este bean, 2 opciones:
	//	1ª poner la anotacion @Autowired
	//  2ª crear el constructor que recibe este bean como parametro
	private IProductosBS bs;
	
	@Value("${server.port}")   // para inyectar valores (tipos primitivos y String)
	private Integer port;
	
	public ProductosREST(IProductosBS bs) {
		super();
		this.bs = bs;
	}

	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return bs.consultarTodos()
				.stream()
				.map(prod -> {
					prod.setPort(port);
					return prod;
				})
				.collect(Collectors.toList());
	}
	
	// http://localhost:8001/buscar/4
	@GetMapping("/buscar/{codigo}")
	public Producto buscar(@PathVariable(name = "codigo") @Min(1) @Max(6)  Long id) {
		Producto producto = bs.buscarProducto(id);
		
		// Si no ha encontrado el producto lanzamos una excepcion
		if (producto.getDescripcion() == null)
			throw new RuntimeException("Ese producto no existe");
		
		producto.setPort(port);
		return producto;
	}
	
	
	@PostMapping("/nuevo/descripcion/{descripcion}/precio/{precio}")
	public Producto nuevo(@PathVariable String descripcion, @PathVariable double precio) {
		return bs.crearProducto(new Producto(descripcion, precio));
	}
	
	@DeleteMapping("/eliminar/{id}")
	public String eliminar(@PathVariable Long id) {
		return bs.eliminarProducto(id);
	}

}









