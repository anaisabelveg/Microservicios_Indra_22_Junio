package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import es.indra.models.Pedido;
import es.indra.models.Producto;

@Service
public class PedidosBSImplRestTemplate implements IPedidosBS{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		/*
		 * Comunicacion entre micro servicios utilizando RestTemplate
		 * */
		
		// Buscar el producto con ese id
		// Utilizando eureka se pone el nombre del servicio
		Producto producto = restTemplate.getForObject(
				"http://servicio-productos/buscar/{codigo}", Producto.class, id);
		
		// Crear el pedido
		Pedido pedido = new Pedido(producto, cantidad);
		
		// Retornar el pedido
		return pedido;
	}

	@Override
	public String pruebaTransaccion(String descripcion, double precio, String nombreProveedor) {
		// TODO Auto-generated method stub
		return "Todo ok";
	}

}
