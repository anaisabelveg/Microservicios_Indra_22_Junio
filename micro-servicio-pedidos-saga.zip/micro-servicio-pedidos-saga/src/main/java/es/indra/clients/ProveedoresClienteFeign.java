package es.indra.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(name = "servicio-proveedores")
public interface ProveedoresClienteFeign {
	
	// Mapear a donde vamos a emitir la peticion
	@PostMapping("/alta/{nombre}")
	public String altaProveedor(@PathVariable String nombre);

}
