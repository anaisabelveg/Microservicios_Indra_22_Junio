<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="es.indra.models.Producto" %>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Insert title here</title>
	</head>
	<body>
		<h1>Producto encontrado</h1>
		
		<jsp:useBean id="encontrado" class="es.indra.models.Producto" scope="request"></jsp:useBean>
		
		<ul>
			<li>ID: <jsp:getProperty property="ID" name="encontrado"/></li>
			<li>Descripcion: <jsp:getProperty property="descripcion" name="encontrado"/></li>
			<li>Precio: <jsp:getProperty property="precio" name="encontrado"/></li>
		</ul>
	</body>
</html>