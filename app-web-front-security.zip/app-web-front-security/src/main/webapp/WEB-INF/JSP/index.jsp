<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Insert title here</title>
	</head>
	<body>
		<h1>Bienvenidos a nuestra tienda WEB</h1>
		
		<a href="todos">Mostrar todos los productos</a> <br/>
		
		<a href="buscar">Buscar un producto</a>
		
	</body>
</html>