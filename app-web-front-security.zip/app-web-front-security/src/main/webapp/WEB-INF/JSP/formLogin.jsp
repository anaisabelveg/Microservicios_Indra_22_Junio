<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Insert title here</title>
	</head>
	<body>
		<h2>Login de usuario</h2>
		
		<form action="login" method="post">
			<label>User:</label>
			<input type="text" name="user" /> <br/>
			
			<label>Password:</label>
			<input type="password" name="pw" /> <br/>
			
			<input type="submit" value="Enviar" />
			
		</form>
	</body>
</html>