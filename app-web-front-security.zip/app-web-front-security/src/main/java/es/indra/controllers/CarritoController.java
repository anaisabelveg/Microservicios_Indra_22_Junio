package es.indra.controllers;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import es.indra.business.IGestionBS;
import es.indra.models.Carrito;

@Controller
@RequestMapping("/")
public class CarritoController {
	
	@Autowired
	private IGestionBS bs;
	
	@PostMapping(value = "comprar")
	public String addPedido(long id, int cantidad, HttpServletRequest request, HttpSession session, Model model) {
		
		String token = (String) session.getAttribute("JWT");
		
		String usuario = null;
		boolean logado = false;
		
		// Recuperar las cookies y comprobar si tenemos el nombre del usuario
		Cookie[] cookies = request.getCookies();
		for (Cookie cookie : cookies) {
			if ("nombreUsuario".equals(cookie.getName())) {
				usuario = cookie.getValue();
				logado = true;
				break;
			}
		}
		
		// Si el usuario no esta logado le enviamos al formulario de login
		if (!logado) return "formLogin";
		
		// Si el usuario si esta logado agregamos el pedido al carrito si tiene permiso
		try{
			bs.agregar(id, cantidad, usuario, token);
			Carrito carrito = bs.consultar(usuario, token);
			request.setAttribute("carrito", carrito);
			return "mostrarCarrito";
		} catch (Exception e) {
			model.addAttribute("msg", "No tienes permisos para esta operacion");
			return "mostrarMensaje";
		}
	}
	
	@GetMapping(value = "sacar")
	public String sacarPedido(long id, String usuario, HttpServletRequest request, HttpSession session, Model model) {
		
		String token = (String) session.getAttribute("JWT");
		
		try {
			bs.eliminar(id, usuario, token);
			Carrito carrito = bs.consultar(usuario, token);
			request.setAttribute("carrito", carrito);
			return "mostrarCarrito";
		} catch (Exception e) {
			model.addAttribute("msg", "No tienes permisos para esta operacion");
			return "mostrarMensaje";
		}
		
	}

}
