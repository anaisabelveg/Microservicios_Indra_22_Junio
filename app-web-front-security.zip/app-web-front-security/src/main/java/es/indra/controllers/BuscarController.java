package es.indra.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.HttpClientErrorException;

import es.indra.business.IGestionBS;
import es.indra.models.Producto;

@Controller
@RequestMapping("/buscar")
public class BuscarController {

    private final LoginController loginController;
	
	@Autowired
	private IGestionBS bs;

    BuscarController(LoginController loginController) {
        this.loginController = loginController;
    }
	
	@RequestMapping(method = RequestMethod.GET)
	public String mostrarFormulario(Model model) {
		model.addAttribute("prod", new Producto());
		return "formBuscar";
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public String procesarFormulario(@ModelAttribute("prod") Producto producto, Model model, HttpSession session) {
//		Producto encontrado = bs.buscar(producto.getID());
//		if (encontrado.getDescripcion() == null) {
//			model.addAttribute("msg", "Ese producto no existe en nuestro catalogo");
//			return "mostrarMensaje";
//		} else {
//			model.addAttribute("encontrado", encontrado);
//			return "mostrarProducto";
//		}	
		
		String token = (String) session.getAttribute("JWT");
		
		try {
			Producto encontrado = bs.buscar(producto.getID(), token);
			model.addAttribute("encontrado", encontrado);
			return "mostrarProducto";
		} catch (HttpClientErrorException e){
			model.addAttribute("msg", "No tienes permisos para solicitar este recurso");
			return "mostrarMensaje";
		} catch (Exception e) {
			System.out.println(e.getClass());
			model.addAttribute("msg", "Ese producto no existe en nuestro catalogo");
			return "mostrarMensaje";
		}
	}

}
