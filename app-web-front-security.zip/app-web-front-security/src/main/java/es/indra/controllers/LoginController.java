package es.indra.controllers;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import es.indra.business.IGestionBS;

@Controller
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
	private IGestionBS bs;
	
	@PostMapping
	public String inicio(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		String usuario = request.getParameter("user");
		Cookie cookie = new Cookie("nombreUsuario", usuario);
		response.addCookie(cookie);
		
		String token = (String) session.getAttribute("JWT");
		
		// Crear el carrito del usuario
		bs.crear(usuario, token);
		
		return "index";
	}

}
