package es.indra.models;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data // getter, setter, equals, hashcode, toString
@NoArgsConstructor // Constructor por defecto
public class Usuario {
	
	private Long id;
	private String username;
	private String password;
	private boolean enabled;
	private String nombre;
	private String apellido;
	private String email;
	private List<Role> roles = new ArrayList<>();
	
	public Usuario(String username, String password, boolean enabled, String nombre, String apellido, String email) {
		super();
		this.username = username;
		this.password = password;
		this.enabled = enabled;
		this.nombre = nombre;
		this.apellido = apellido;
		this.email = email;
	}

}
