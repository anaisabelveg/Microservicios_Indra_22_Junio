package es.indra.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.KafkaListeners;
import org.springframework.stereotype.Service;

@Service
public class Consumidor {
	
	// Si escucho de varios topics hay 2 formas de hacerlo:
	// 1ª opcion:
	// @KafkaListener(topics = {"topic1", "topic2", "topic3"})
	
	// 2ª opcion:
//	@KafkaListeners({
//		@KafkaListener(topics = "topic1"),
//		@KafkaListener(topics = "topic2"),
//		@KafkaListener(topics = "topic3")
//	})
	
	@KafkaListener(topics = "indra-cluster")
	public void recibirComentario(String comentario) {
		System.out.println("*************************************");
		System.out.println("Comentario recibido: " + comentario);
		System.out.println("*************************************");
	}

}
