package es.indra.business;

public interface IProveedoresBS {
	
	String crearProveedor(String nombre);

}
