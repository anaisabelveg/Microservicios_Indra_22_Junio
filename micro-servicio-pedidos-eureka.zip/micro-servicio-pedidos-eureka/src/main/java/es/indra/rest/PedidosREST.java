package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IPedidosBS;
import es.indra.models.Pedido;

@RestController
public class PedidosREST {
	
	@Autowired
	private IPedidosBS bs;
	
	// http://localhost:8002/crear/4/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	public Pedido crear(@PathVariable Long id, @PathVariable int cantidad) {
		return bs.crearPedido(id, cantidad);
	}
	
	// Utilizando Hystrix (try-catch) capturamos la excepcion de buscar producto que existe
	// Se crea un metodo alternativo (catch) se ejecuta cuando hay un error

}
