package es.indra.business;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import es.indra.clients.ProductosClienteFeign;
import es.indra.models.Pedido;
import es.indra.models.Producto;

@Service
@Primary  // Damos preferencia para quer inyecte este bean
public class PedidosBSImplFeign implements IPedidosBS {

	private ProductosClienteFeign clienteFeign;

	// Inyectamos a traves del constructor
	public PedidosBSImplFeign(ProductosClienteFeign clienteFeign) {
		super();
		this.clienteFeign = clienteFeign;
	}

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		// Buscar el producto con ese id
		Producto producto = clienteFeign.buscar(id);
		
		// Crear el pedido
		Pedido pedido = new Pedido(producto, cantidad);
		
		// Retornar el pedido
		return pedido;
	}

}
