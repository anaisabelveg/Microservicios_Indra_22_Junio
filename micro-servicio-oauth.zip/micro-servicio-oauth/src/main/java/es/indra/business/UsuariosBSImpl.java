package es.indra.business;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import es.indra.clients.UsuariosClienteFeign;
import es.indra.models.Usuario;

@Service
public class UsuariosBSImpl implements IUsuariosBS, UserDetailsService {

	private UsuariosClienteFeign clienteFeign;

	public UsuariosBSImpl(UsuariosClienteFeign clienteFeign) {
		super();
		this.clienteFeign = clienteFeign;
	}

	@Override
	public Usuario buscarUsuario(String username) {
		return clienteFeign.findByUsername(username);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// Este metodo convierte el usuario obtenido del micro-servicio-usuarios en un usuario de Spring Security
		Usuario usuario = buscarUsuario(username);
		
		if (usuario == null) {
			throw new UsernameNotFoundException("No existe usuario con ese username " + username);
		}
		
		// Crear una lista con los roles del usuario
		List<GrantedAuthority> permisos = usuario.getRoles()
				.stream()
				.map(role -> new SimpleGrantedAuthority(role.getNombre()))
				.collect(Collectors.toList());
		
		
		return new User(usuario.getUsername(), usuario.getPassword(), usuario.isEnabled(), true, true, true, permisos);
	}

}












